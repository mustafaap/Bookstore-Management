/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package project.pkg2;

/**
 *
 * @author musta
 */
public interface MemberInterface {
    
    public String getFirstName();
            
    public String getLastName();
    
    public void setFirstName(String firstName);
    
    public void setLastName(String lastName);
}
